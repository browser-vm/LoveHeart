const uvRandomPath = "YhJbqP0dDB";

export { uvRandomPath };